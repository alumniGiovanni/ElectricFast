export class CartItem {
  public productId: string;
  public quantity: number = 0;
}
